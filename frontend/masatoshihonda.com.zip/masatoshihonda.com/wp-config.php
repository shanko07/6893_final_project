<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'xbrw0_8ek43787' );

/** MySQL database username */
define( 'DB_USER', 'xbrw0_56t35638' );

/** MySQL database password */
define( 'DB_PASSWORD', 'YR6Xd-d743' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql47.onamae.ne.jp' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'STAk{d +x{/q~,zolg^mdVO&emnK8O07`JWgP&sgY-%0KgBxJM@k(/}zHmd7Q&O=' );
define( 'SECURE_AUTH_KEY',   '9 :gHJ3Gn&yD6>qQR15DB4J^.3$8)@{UMlFpj=8XB-|}QM668&{auFz9qbh<`EM5' );
define( 'LOGGED_IN_KEY',     '3,lwN?J{RgrM{%j E^ M@Bfikz^oWc42lT]F&e*<#QfK0nn*>??^l|!_ZC^TzDuA' );
define( 'NONCE_KEY',         '_/kK MSTgm!oEJc^X,av[+?FY{LJ;S~59v3g7J{f1:^F;&uy,`CeT[AmkiI.9~a*' );
define( 'AUTH_SALT',         'P(o:NvJ%b*puen]0irlT:.. =tN.E~KULVebejy=#?Q~F%>6+o7qJ/EMDudG*smA' );
define( 'SECURE_AUTH_SALT',  '%2{_-~%5JbA-|13x0$)sSs,kfgiV1T51-G,s5^=RDg(=ZU!CYtva7_A&k+%su$%U' );
define( 'LOGGED_IN_SALT',    '3plhB(w8Q=_{LUqlquqI0%~9ftOJ1Hw}1,YqVatSd{Q^-w-YA@f(D.G;=]m_jXUv' );
define( 'NONCE_SALT',        'bV~=+o9lA&vTD?_H+vhx`3H.<8G}qXOL3}M|-H`k8aqUKei.VGk)q<-fzOR[pjQy' );
define( 'WP_CACHE_KEY_SALT', 'gRa7~Y~- 6<=[9YeE 2v/MF#ySF<O2N~9C8FY77#@a &%r8zO1YSN{[-^K`@iCGj' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === "https") {
    $_SERVER['HTTPS'] = 'on';
    define('FORCE_SSL_LOGIN', true);
    define('FORCE_SSL_ADMIN', true);
}




define( 'RS_DASHBOARD_PLUGIN_SID', 'PQ6M7OdvDuXFZDpYxdjCE4kEBd7DWFFuXHraTdf5in5UGnPIznNfu9_DzQ8qGay9K1YLUvv76ZqrbY87AeObi5ZAPP293MB6eSVnqkUBjPo.' );
define( 'RS_DASHBOARD_PLUGIN_DID', 'R6nGLRRlEFDRJxAtUdTvfc9jsDAkhtcvi4T20SALBpTVdX_2eDRpszAJECOCx7ml2XkcwHs9OPvviuHJ7_A1MLtznt13pKiIVBZHoeCvMfI.' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
